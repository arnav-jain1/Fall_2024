/* myprog.c */
#include <unistd.h>
int main()
{
sleep(1);
return 0;
}